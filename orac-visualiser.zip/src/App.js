import React from "react";

import Info from "./Info";
import Citations from "./Citations";
import Nav from "./Nav";
import Resources from "./Resources";
import BaseButtons from "./BaseButtons";
import "./App.css";

function App() {
  const targetRef = React.useRef(null);
  // const size = useResponsiveBreakpoints(targetRef, [
  //   { small: 200 },
  //   { medium: 400 },
  //   { large: 600 }
  // ]);

  return (
    <React.Fragment>
      <Nav />
      <div className="row">
        <div className="lg-5 col">
          <div className="paper">
            <Info />
          </div>
        </div>
        <BaseButtons />
        <div className="lg-12 col">
          <Resources />
          <Citations />
        </div>
      </div>
    </React.Fragment>
  );
}

export default App;
