import React from "react";
import skeleton from "./images/skeleton.png";

export default function Info() {
  return (
    <div className="lg-12 col">
    <header>
      <h1 className="title">ORAC</h1>
      <img className="image" src={skeleton} />
      {/* <p>
        You'll notice a resizable box with some text inside it. When you pull
        the handle left or right to change the size, the text within the box
        will change to some breakpoints.
        <br />
        We can define breakpoints in our hook like so.
        <br />
        <code>
          {[
            `[{ small: 200 },`,
            <br />,
            `{ medium: 400 },`,
            <br />,
            `{ large: 600 }]`
          ]}
        </code>
      </p> */}
    </header>
    </div>
  );
}
