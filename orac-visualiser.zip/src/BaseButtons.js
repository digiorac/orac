import React from "react";
import oracData from "./oracData";

export default function BaseButtons() {
  const targetRef = React.useRef(null);
  const [step, setStep] = React.useState(0);
  const [oracType, setOracType] = React.useState("");
  const [curHeader, setCurHeader] = React.useState("ORAC Guidelines");
  const [bodyRegions, setBodyRegions] = React.useState([]);
  const [bodyRegion, setBodyRegion] = React.useState("");
  const [clinicalIndications, setClinicalIndications] = React.useState([]);
  const [clinicalIndication, setClinicalIndication] = React.useState("");
  const [appropriatenessCriteria, setAppropriatenessCriteria] = React.useState([]);
  const [clinicalConsiderations, setClinicalConsiderations] = React.useState([]);
  const [recommendedProjections, setRecommendedProjections] = React.useState("");
  const [xRayRemarks, setXRayRemarks] = React.useState([]);
  const [referralImagingRequirements, setReferralImagingRequirements] = React.useState("");

  const uniqueOracTypes = [...new Set(oracData.map(item => item.oracType))];

  function setStatus(step) {
    setStep(step);

    switch (step) {
      case 1:
        setCurHeader("Body Region");
        break;
      case 2:
        setCurHeader("Clinical Indication");
        break;
      case 3:
        setCurHeader("Appropriateness Criteria");
        break;
      case 4:
        setCurHeader("Clinical Considerations");
        break;
      case 5:
        setCurHeader("Recommended Projections");
        break;
      case 6:
        setCurHeader("X-Ray (XR) Remarks");
        break;
      case 7:
        setCurHeader("Orthopaedic Referral Imaging Requirements");
        break;
      default:
        setCurHeader("ORAC Guidelines");
    }
  }

  function populateBodyRegions(oracType) {
    const relevantData = oracData.filter(item => item.oracType === oracType);
    setBodyRegions([...new Set(oracData.filter(item => item.oracType === oracType).map(item => item.bodyRegion))]);
  }

  function populateClinicalIndications(bodyRegion) {
    const relevantData = oracData.filter(item => item.bodyRegion === bodyRegion);
    const result = [];
    relevantData.forEach(record =>
      record.information.forEach(
        item => result.push(item.clinicalIndication)
      )
    )
    setClinicalIndications([...new Set(result)]);
  }

  function populateRestOfData(clinicalIndication) {
    const relevantData = oracData.filter(item => item.bodyRegion === bodyRegion);

    for (let i = 0; i < relevantData[0].information.length; i++) {
      if (relevantData[0].information[i].clinicalIndication === clinicalIndication) {
        let info = relevantData[0].information[i];
        setAppropriatenessCriteria(info.appropriatenessCriteria);
        setClinicalConsiderations(info.clinicalConsiderations);
        setRecommendedProjections(info.recommendedProjections);
        setXRayRemarks(info.xRayRemarks);
        setReferralImagingRequirements(info.referralImagingRequirements);
      }
    }
  }



  return (
    <div className="lg-7 col">
      <div className="paper">
        <div
          className="article-title"
          style={{
            resize: "horizontal",
            overflow: "hidden",
            textAlign: "center"
          }}>
          <h3>{curHeader}</h3>
        </div>
        {(() => {
          switch (step) {
            case 1: return bodyRegions.map((bodyRegion, index) => {
              return <div className="row">
                <div className="col-fill col" style={{ overflow: "hidden" }} >
                  <button
                    class="btn-block"
                    style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                    onClick={() => {
                      setStatus(2);
                      setBodyRegion(bodyRegion);
                      populateClinicalIndications(bodyRegion);
                    }}>
                    <div
                      ref={targetRef}
                      className="border"
                      style={{
                        backgroundColor: "aliceblue",
                        padding: "0rem",
                        resize: "horizontal",
                        overflow: "hidden",
                        maxWidth: "100%",
                        minWidth: "4rem"
                      }}
                    >
                      <h4 style={{ fontSize: '30px' }}>{bodyRegion}</h4>
                    </div>
                  </button>
                </div>
              </div>
            });
            case 2: return clinicalIndications.map((clinicalIndication, index) => {
              return <div className="row">
                <div className="col-fill col" style={{ overflow: "hidden" }} >
                  <button
                    class="btn-block"
                    style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                    onClick={() => {
                      setStatus(3);
                      setClinicalIndication(clinicalIndication);
                      populateRestOfData(clinicalIndication);
                    }}>
                    <div
                      ref={targetRef}
                      className="border"
                      style={{
                        backgroundColor: "aliceblue",
                        padding: "0rem",
                        resize: "horizontal",
                        overflow: "hidden",
                        maxWidth: "100%",
                        minWidth: "4rem"
                      }}
                    >
                      <h4 style={{ fontSize: '30px' }}>{clinicalIndication}</h4>
                    </div>
                  </button>
                </div>
              </div>
            });
            case 3:
              return <div>
                <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }}>
                    <div style={{ overflow: "hidden", width: "100%" }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "1rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        {appropriatenessCriteria.remarks}
                      </div>
                    </div>
                  </div>
                </div>
                {appropriatenessCriteria.conditions.length !== 0 ?
                  <div className="row">
                    <div className="col-fill col" style={{ overflow: "hidden" }}>
                      <div style={{ overflow: "hidden", width: "100%" }}>
                        <div
                          ref={targetRef}
                          className="border"
                          style={{
                            backgroundColor: "aliceblue",
                            padding: "1rem",
                            resize: "horizontal",
                            overflow: "hidden",
                            maxWidth: "100%",
                            minWidth: "4rem"
                          }}
                        >
                          {appropriatenessCriteria.conditions.map((item, index) => {
                            return <fieldset class="form-group">
                              <label for={"paperChecksA" + index} class="paper-check">
                                <input type="checkbox" name="paperChecks" id={"paperChecksA" + index} value={"paperChecksA" + index} /> <span>{item}</span>
                              </label>
                            </fieldset>
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                  : <div></div>}
                {appropriatenessCriteria.remarks2 !== "" ?
                <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }}>
                    <div style={{ overflow: "hidden", width: "100%" }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "1rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        {appropriatenessCriteria.remarks2}
                      </div>
                    </div>
                  </div>
                </div>
                : <div></div>}
                {appropriatenessCriteria.conditions2.length !== 0 ?
                  <div className="row">
                    <div className="col-fill col" style={{ overflow: "hidden" }}>
                      <div style={{ overflow: "hidden", width: "100%" }}>
                        <div
                          ref={targetRef}
                          className="border"
                          style={{
                            backgroundColor: "aliceblue",
                            padding: "1rem",
                            resize: "horizontal",
                            overflow: "hidden",
                            maxWidth: "100%",
                            minWidth: "4rem"
                          }}
                        >
                          {appropriatenessCriteria.conditions2.map((item, index) => {
                            return <fieldset class="form-group">
                              <label for={"paperChecksB" + index} class="paper-check">
                                <input type="checkbox" name="paperChecks" id={"paperChecksB" + index} value={"paperChecksA" + index} /> <span>{item}</span>
                              </label>
                            </fieldset>
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                  : <div></div>}
                <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <button
                      class="btn-block"
                      style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                      onClick={() => {
                        setStatus(4);
                      }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "0rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        <h4 style={{ fontSize: '30px' }}>Move on to Clinical Considerations</h4>
                      </div>
                    </button>
                  </div>
                </div>
              </div>;
            case 4: return <div>
            {clinicalConsiderations.map((clinicalConsideration, index) => {
              return <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <div style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "1rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        {clinicalConsideration}
                      </div>
                    </div>
                  </div>
                </div>
            })}
            <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <button
                      class="btn-block"
                      style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                      onClick={() => {
                        setStatus(5);
                      }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "0rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        <h4 style={{ fontSize: '30px' }}>Move on to Recommended Projections</h4>
                      </div>
                    </button>
                  </div>
                </div>
            </div>
            ;
            case 5: return <div>
            {recommendedProjections.map((recommendedProjection, index) => {
              return <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <div style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "1rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        {recommendedProjection}
                      </div>
                    </div>
                  </div>
                </div>
            })}
            <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <button
                      class="btn-block"
                      style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                      onClick={() => {
                        setStatus(6);
                      }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "0rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        <h4 style={{ fontSize: '30px' }}>Move on to X-Ray Remarks</h4>
                      </div>
                    </button>
                  </div>
                </div>
            </div>
            ;
            case 6: return <div>
            {xRayRemarks.map((xRayRemark, index) => {
              return <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <div style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "1rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        {xRayRemark}
                      </div>
                    </div>
                  </div>
                </div>
            })}
            <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <button
                      class="btn-block"
                      style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                      onClick={() => {
                        setStatus(7);
                      }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "0rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        <h4 style={{ fontSize: '30px' }}>Move on to Referral Imaging Requirements</h4>
                      </div>
                    </button>
                  </div>
                </div>
            </div>
            ;
            case 7: return <div>
            {referralImagingRequirements.map((requirement, index) => {
              return <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <div style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "1rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        {requirement}
                      </div>
                    </div>
                  </div>
                </div>
            })}
            <div className="row">
                  <div className="col-fill col" style={{ overflow: "hidden" }} >
                    <button
                      class="btn-block"
                      style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                      onClick={() => {
                        setStatus(0);
                      }}>
                      <div
                        ref={targetRef}
                        className="border"
                        style={{
                          backgroundColor: "aliceblue",
                          padding: "0rem",
                          resize: "horizontal",
                          overflow: "hidden",
                          maxWidth: "100%",
                          minWidth: "4rem"
                        }}
                      >
                        <h4 style={{ fontSize: '30px' }}>Finish</h4>
                      </div>
                    </button>
                  </div>
                </div>
            </div>
            default: return uniqueOracTypes.map((oracType, index) => {
              return <div className="row">
                <div className="col-fill col" style={{ overflow: "hidden" }} >
                  <button
                    class="btn-block"
                    style={{ overflow: "hidden", width: "100%", wordWrap: "break-word" }}
                    onClick={() => {
                      setStatus(1);
                      setOracType(oracType);
                      populateBodyRegions(oracType);
                    }}>
                    <div
                      ref={targetRef}
                      className="border"
                      style={{
                        backgroundColor: "aliceblue",
                        padding: "0rem",
                        resize: "horizontal",
                        overflow: "hidden",
                        maxWidth: "100%",
                        minWidth: "4rem"
                      }}
                    >
                      <h4 style={{ fontSize: '30px' }}>{oracType}</h4>
                    </div>
                  </button>
                </div>
              </div>
            });
          }
        })()}
      </div>
    </div>
  );
}

