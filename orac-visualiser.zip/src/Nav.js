import React from "react";

export default function Nav() {
  return (
    <nav>
      <div className="nav-brand">
        <h3>ORAC Visualiser</h3>
      </div>
      <div className="collapsible">
        <input id="collapsible1" type="checkbox" name="collapsible1" />
        <div className="collapsible-body">
          <ul className="inline">
          </ul>
        </div>
      </div>
    </nav>
  );
}
