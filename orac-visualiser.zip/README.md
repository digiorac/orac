<img src="https://blog.sethcorker.com/content/images/size/w2000/2019/10/Medium.jpg" alt="A title card with the text: Resize Observer API with React"/>

# Example of Resize Observer API with React

- [Demo](https://example-react-resize-observer.sethcorker.com/)
- My [article describing the Resize Observer API in a bit more detail](https://blog.sethcorker.com/resize-observer-api/)

## What is this?

An example of the Resize Observer API being used in React with a custom hook.

## How can I run it?

Once you've cloned the repo, make sure you have node and npm installed. Then just run the usual:
`npm start`

Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.
